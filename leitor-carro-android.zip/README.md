# Leitor Carro

Aplicação Android nativa em Kotlin (Jetpack Compose Material 3 + Media3 ExoPlayer) concebida para utilização no ecrã do rádio do carro através de espelhamento do telemóvel.

## Requisitos técnicos
- `minSdk = 26` (Android 8.0) / `targetSdk = 34` (Android 14)
- Interface em português de Portugal
- Tema escuro de alto contraste com botões com pelo menos `72 dp`
- Ecrã sempre ligado enquanto a aplicação está aberta
- Sem anúncios e sem contas de utilizador

## Como gerar o APK no GitHub Actions
1. Crie um repositório no GitHub e envie o conteúdo desta pasta.
2. Aceda ao separador **Actions** no GitHub.
3. Abra o workflow **Compilar APK Debug (Leitor Carro)** (executa automaticamente no `push` ou manualmente em **Run workflow**).
4. No final da compilação, transfira o artefacto **`leitor-carro-debug-apk`** (`app-debug.apk`).

## Como instalar no telemóvel
1. Transfira o ficheiro `app-debug.apk` para o telemóvel.
2. Toque no ficheiro e autorize **"Instalar aplicações desconhecidas"** para o gestor de ficheiros ou navegador.
3. Confirme a instalação e abra **Leitor Carro**.
