# Regras ProGuard para o Leitor Carro
-keepattributes SourceFile,LineNumberTable
