package pt.leitorcarro.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.Player
import org.json.JSONArray
import org.json.JSONObject
import pt.leitorcarro.app.model.MediaMode
import pt.leitorcarro.app.model.MediaTrack
import pt.leitorcarro.app.model.SavedPlaybackState

class PlaylistStorage(context: Context) {

    private val prefs = context.getSharedPreferences("leitor_carro_prefs", Context.MODE_PRIVATE)
    private val appContext = context.applicationContext

    fun saveState(mode: MediaMode, state: SavedPlaybackState) {
        val jsonArray = JSONArray()
        state.tracks.forEach { track ->
            val obj = JSONObject()
            obj.put("uri", track.uriString)
            obj.put("name", track.displayName)
            jsonArray.put(obj)
        }

        prefs.edit()
            .putString(keyTracks(mode), jsonArray.toString())
            .putInt(keyIndex(mode), state.currentIndex)
            .putLong(keyPosition(mode), state.positionMs)
            .putBoolean(keyShuffle(mode), state.shuffleEnabled)
            .putInt(keyRepeat(mode), state.repeatMode)
            .apply()
    }

    fun loadState(mode: MediaMode): SavedPlaybackState {
        val rawJson = prefs.getString(keyTracks(mode), null)
        val tracks = mutableListOf<MediaTrack>()
        if (!rawJson.isNullOrBlank()) {
            try {
                val arr = JSONArray(rawJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val uri = obj.optString("uri", "")
                    val name = obj.optString("name", "Ficheiro sem nome")
                    if (uri.isNotBlank()) {
                        tracks.add(MediaTrack(uriString = uri, displayName = name))
                    }
                }
            } catch (_: Exception) {
                // Ignora dados corrompidos e começa lista vazia
            }
        }

        val index = prefs.getInt(keyIndex(mode), 0)
            .coerceIn(0, (tracks.size - 1).coerceAtLeast(0))
        val position = prefs.getLong(keyPosition(mode), 0L).coerceAtLeast(0L)
        val shuffle = prefs.getBoolean(keyShuffle(mode), false)
        val repeat = prefs.getInt(keyRepeat(mode), Player.REPEAT_MODE_OFF)

        return SavedPlaybackState(
            tracks = tracks,
            currentIndex = index,
            positionMs = position,
            shuffleEnabled = shuffle,
            repeatMode = repeat
        )
    }

    fun saveLastActiveMode(mode: MediaMode) {
        prefs.edit().putString("last_active_mode", mode.storageKey).apply()
    }

    fun loadLastActiveMode(): MediaMode? {
        val key = prefs.getString("last_active_mode", null) ?: return null
        return MediaMode.entries.firstOrNull { it.storageKey == key }
    }

    fun resolvePickedUris(uris: List<Uri>): List<MediaTrack> {
        val resolver = appContext.contentResolver
        return uris.map { uri ->
            try {
                resolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Alguns fornecedores não permitem permissão persistente, mantém acesso na sessão atual
            } catch (_: Exception) {
            }

            val name = queryDisplayName(uri) ?: uri.lastPathSegment ?: "Ficheiro multimédia"
            MediaTrack(uriString = uri.toString(), displayName = name)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            appContext.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun keyTracks(mode: MediaMode) = "tracks_${mode.storageKey}"
    private fun keyIndex(mode: MediaMode) = "index_${mode.storageKey}"
    private fun keyPosition(mode: MediaMode) = "position_${mode.storageKey}"
    private fun keyShuffle(mode: MediaMode) = "shuffle_${mode.storageKey}"
    private fun keyRepeat(mode: MediaMode) = "repeat_${mode.storageKey}"
}
