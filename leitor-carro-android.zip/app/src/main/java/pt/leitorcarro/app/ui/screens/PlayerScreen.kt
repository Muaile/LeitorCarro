package pt.leitorcarro.app.ui.screens

import android.content.res.Configuration
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import pt.leitorcarro.app.data.PlaylistStorage
import pt.leitorcarro.app.model.MediaMode
import pt.leitorcarro.app.model.MediaTrack
import pt.leitorcarro.app.model.SavedPlaybackState
import pt.leitorcarro.app.ui.components.CarActionButton
import pt.leitorcarro.app.ui.components.CarControlIconButton
import pt.leitorcarro.app.ui.components.formatDurationMs
import pt.leitorcarro.app.ui.theme.CarColors

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    mode: MediaMode,
    mediaController: MediaController?,
    activeServiceMode: MediaMode?,
    onActiveServiceModeChange: (MediaMode) -> Unit,
    storage: PlaylistStorage,
    onNavigateHome: () -> Unit
) {
    val context = LocalContext.current
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var tracks by remember(mode) { mutableStateOf<List<MediaTrack>>(emptyList()) }
    var currentIndex by remember(mode) { mutableIntStateOf(0) }
    var positionMs by remember(mode) { mutableLongStateOf(0L) }
    var durationMs by remember(mode) { mutableLongStateOf(0L) }
    var isPlaying by remember(mode) { mutableStateOf(false) }
    var shuffleEnabled by remember(mode) { mutableStateOf(false) }
    var repeatMode by remember(mode) { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var errorMessage by remember(mode) { mutableStateOf<String?>(null) }
    var showPlaylistOnPortrait by remember(mode) { mutableStateOf(false) }
    var isSeeking by remember { mutableStateOf(false) }
    var sliderProgress by remember { mutableFloatStateOf(0f) }

    fun persistCurrentState(
        list: List<MediaTrack> = tracks,
        idx: Int = currentIndex,
        pos: Long = positionMs,
        shuf: Boolean = shuffleEnabled,
        rep: Int = repeatMode
    ) {
        storage.saveState(
            mode = mode,
            state = SavedPlaybackState(
                tracks = list,
                currentIndex = idx.coerceIn(0, (list.size - 1).coerceAtLeast(0)),
                positionMs = pos.coerceAtLeast(0L),
                shuffleEnabled = shuf,
                repeatMode = rep
            )
        )
        storage.saveLastActiveMode(mode)
    }

    fun buildMediaItems(list: List<MediaTrack>): List<MediaItem> {
        return list.map { track ->
            MediaItem.Builder()
                .setUri(Uri.parse(track.uriString))
                .setMediaId(track.uriString)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.displayName)
                        .setArtist(if (mode == MediaMode.AUDIO) "Leitor Carro · Música" else "Leitor Carro · Vídeo")
                        .build()
                )
                .build()
        }
    }

    // Carregar estado guardado e ligar ao MediaController
    LaunchedEffect(mode, mediaController) {
        val saved = storage.loadState(mode)
        tracks = saved.tracks
        currentIndex = saved.currentIndex
        positionMs = saved.positionMs
        shuffleEnabled = saved.shuffleEnabled
        repeatMode = saved.repeatMode
        errorMessage = null

        val controller = mediaController ?: return@LaunchedEffect

        val alreadyPlayingSameMode =
            activeServiceMode == mode && controller.mediaItemCount == saved.tracks.size && saved.tracks.isNotEmpty()

        if (alreadyPlayingSameMode) {
            currentIndex = controller.currentMediaItemIndex.coerceIn(0, (saved.tracks.size - 1).coerceAtLeast(0))
            positionMs = controller.currentPosition.coerceAtLeast(0L)
            durationMs = controller.duration.coerceAtLeast(0L)
            isPlaying = controller.isPlaying
            shuffleEnabled = controller.shuffleModeEnabled
            repeatMode = controller.repeatMode
        } else {
            onActiveServiceModeChange(mode)
            controller.shuffleModeEnabled = saved.shuffleEnabled
            controller.repeatMode = saved.repeatMode

            if (saved.tracks.isNotEmpty()) {
                val items = buildMediaItems(saved.tracks)
                val startIdx = saved.currentIndex.coerceIn(0, items.lastIndex)
                controller.setMediaItems(items, startIdx, saved.positionMs)
                controller.prepare()
                durationMs = controller.duration.coerceAtLeast(0L)
                isPlaying = controller.isPlaying
            } else {
                controller.clearMediaItems()
                durationMs = 0L
                isPlaying = false
            }
        }
    }

    // Ouvinte de eventos do leitor (alteração de faixa, pausa/play, erros)
    DisposableEffect(mediaController, mode) {
        val controller = mediaController
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (!playing) {
                    positionMs = controller?.currentPosition?.coerceAtLeast(0L) ?: positionMs
                    persistCurrentState()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (controller != null) {
                    currentIndex = controller.currentMediaItemIndex
                        .coerceIn(0, (tracks.size - 1).coerceAtLeast(0))
                    positionMs = controller.currentPosition.coerceAtLeast(0L)
                    durationMs = controller.duration.coerceAtLeast(0L)
                    errorMessage = null
                    persistCurrentState()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (controller != null) {
                    durationMs = controller.duration.coerceAtLeast(0L)
                    positionMs = controller.currentPosition.coerceAtLeast(0L)
                }
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffleEnabled = shuffleModeEnabled
                persistCurrentState(shuf = shuffleModeEnabled)
            }

            override fun onRepeatModeChanged(newRepeatMode: Int) {
                repeatMode = newRepeatMode
                persistCurrentState(rep = newRepeatMode)
            }

            override fun onPlayerError(error: PlaybackException) {
                val failedName = tracks.getOrNull(currentIndex)?.displayName ?: "ficheiro selecionado"
                errorMessage = "Não foi possível reproduzir \"$failedName\". Verifique se o ficheiro ainda existe ou é suportado."
                isPlaying = false
            }
        }

        controller?.addListener(listener)

        onDispose {
            controller?.removeListener(listener)
            if (controller != null && activeServiceMode == mode) {
                positionMs = controller.currentPosition.coerceAtLeast(0L)
                currentIndex = controller.currentMediaItemIndex
                    .coerceIn(0, (tracks.size - 1).coerceAtLeast(0))
                persistCurrentState()
            }
        }
    }

    // Atualização periódica da barra de progresso e gravação da posição
    LaunchedEffect(mediaController, mode) {
        var saveCounter = 0
        while (true) {
            val controller = mediaController
            if (controller != null && activeServiceMode == mode) {
                if (!isSeeking) {
                    val pos = controller.currentPosition.coerceAtLeast(0L)
                    val dur = controller.duration.coerceAtLeast(0L)
                    positionMs = pos
                    durationMs = dur
                    sliderProgress = if (dur > 0L) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f
                }
                isPlaying = controller.isPlaying
                if (controller.currentMediaItemIndex in tracks.indices) {
                    currentIndex = controller.currentMediaItemIndex
                }

                saveCounter++
                if (saveCounter >= 4 && tracks.isNotEmpty()) {
                    saveCounter = 0
                    persistCurrentState()
                }
            }
            delay(500L)
        }
    }

    // Seletor de ficheiros do sistema (sem permissão de armazenamento)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val picked = storage.resolvePickedUris(uris)
            tracks = picked
            currentIndex = 0
            positionMs = 0L
            errorMessage = null
            persistCurrentState(list = picked, idx = 0, pos = 0L)

            val controller = mediaController
            if (controller != null) {
                onActiveServiceModeChange(mode)
                controller.setMediaItems(buildMediaItems(picked), 0, 0L)
                controller.prepare()
                controller.play()
            }
        }
    }

    BackHandler {
        onNavigateHome()
    }

    val currentTrack = tracks.getOrNull(currentIndex)
    val mimeTypes = if (mode == MediaMode.VIDEO) arrayOf("video/*") else arrayOf("audio/*")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CarColors.Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Barra superior com botões >= 72 dp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CarActionButton(
                    text = "Início",
                    icon = Icons.Rounded.Home,
                    onClick = onNavigateHome,
                    containerColor = CarColors.SurfaceElevated
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = mode.titlePt,
                        style = MaterialTheme.typography.headlineMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentTrack?.displayName ?: "Sem ficheiros selecionados",
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (!isLandscape && tracks.isNotEmpty()) {
                    CarActionButton(
                        text = if (showPlaylistOnPortrait) "Leitor" else "Lista (${tracks.size})",
                        icon = Icons.Rounded.QueueMusic,
                        onClick = { showPlaylistOnPortrait = !showPlaylistOnPortrait },
                        containerColor = if (showPlaylistOnPortrait) CarColors.AccentBlue else CarColors.SurfaceElevated
                    )
                }

                CarActionButton(
                    text = "Escolher ficheiros",
                    icon = Icons.Rounded.FolderOpen,
                    onClick = { filePickerLauncher.launch(mimeTypes) },
                    containerColor = CarColors.AccentAmber,
                    contentColor = CarColors.OnAccentDark
                )
            }

            // Conteúdo principal
            if (tracks.isEmpty()) {
                EmptyPlaylistView(
                    mode = mode,
                    onPickFiles = { filePickerLauncher.launch(mimeTypes) },
                    modifier = Modifier.weight(1f)
                )
            } else if (isLandscape) {
                // Em horizontal: área do leitor + controlos à esquerda, lista de reprodução à direita
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1.45f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MediaViewport(
                            mode = mode,
                            mediaController = mediaController,
                            currentTrackName = currentTrack?.displayName ?: "",
                            isPlaying = isPlaying,
                            errorMessage = errorMessage,
                            canSkipNext = tracks.size > 1,
                            onSkipNextOnError = {
                                errorMessage = null
                                mediaController?.seekToNextMediaItem()
                                mediaController?.prepare()
                                mediaController?.play()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        )

                        PlaybackControlsSection(
                            positionMs = if (isSeeking) (sliderProgress * durationMs).toLong() else positionMs,
                            durationMs = durationMs,
                            sliderProgress = sliderProgress,
                            isPlaying = isPlaying,
                            shuffleEnabled = shuffleEnabled,
                            repeatMode = repeatMode,
                            hasTracks = tracks.isNotEmpty(),
                            onSeekChange = { value ->
                                isSeeking = true
                                sliderProgress = value
                            },
                            onSeekFinished = {
                                val target = (sliderProgress * durationMs).toLong()
                                mediaController?.seekTo(target)
                                positionMs = target
                                isSeeking = false
                            },
                            onPrevious = { mediaController?.seekToPreviousMediaItem() },
                            onReplay10 = { mediaController?.seekBack() },
                            onPlayPause = {
                                if (mediaController != null) {
                                    if (mediaController.isPlaying) {
                                        mediaController.pause()
                                    } else {
                                        mediaController.prepare()
                                        mediaController.play()
                                    }
                                }
                            },
                            onForward10 = { mediaController?.seekForward() },
                            onNext = { mediaController?.seekToNextMediaItem() },
                            onToggleShuffle = {
                                mediaController?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
                            },
                            onCycleRepeat = {
                                mediaController?.let {
                                    it.repeatMode = when (it.repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                }
                            }
                        )
                    }

                    PlaylistColumn(
                        tracks = tracks,
                        currentIndex = currentIndex,
                        onSelectTrack = { index ->
                            errorMessage = null
                            mediaController?.seekTo(index, 0L)
                            mediaController?.prepare()
                            mediaController?.play()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                }
            } else {
                // Em vertical: alterna ou mostra leitor + controlos e lista
                if (showPlaylistOnPortrait) {
                    PlaylistColumn(
                        tracks = tracks,
                        currentIndex = currentIndex,
                        onSelectTrack = { index ->
                            errorMessage = null
                            mediaController?.seekTo(index, 0L)
                            mediaController?.prepare()
                            mediaController?.play()
                            showPlaylistOnPortrait = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MediaViewport(
                            mode = mode,
                            mediaController = mediaController,
                            currentTrackName = currentTrack?.displayName ?: "",
                            isPlaying = isPlaying,
                            errorMessage = errorMessage,
                            canSkipNext = tracks.size > 1,
                            onSkipNextOnError = {
                                errorMessage = null
                                mediaController?.seekToNextMediaItem()
                                mediaController?.prepare()
                                mediaController?.play()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        )

                        PlaybackControlsSection(
                            positionMs = if (isSeeking) (sliderProgress * durationMs).toLong() else positionMs,
                            durationMs = durationMs,
                            sliderProgress = sliderProgress,
                            isPlaying = isPlaying,
                            shuffleEnabled = shuffleEnabled,
                            repeatMode = repeatMode,
                            hasTracks = tracks.isNotEmpty(),
                            onSeekChange = { value ->
                                isSeeking = true
                                sliderProgress = value
                            },
                            onSeekFinished = {
                                val target = (sliderProgress * durationMs).toLong()
                                mediaController?.seekTo(target)
                                positionMs = target
                                isSeeking = false
                            },
                            onPrevious = { mediaController?.seekToPreviousMediaItem() },
                            onReplay10 = { mediaController?.seekBack() },
                            onPlayPause = {
                                if (mediaController != null) {
                                    if (mediaController.isPlaying) {
                                        mediaController.pause()
                                    } else {
                                        mediaController.prepare()
                                        mediaController.play()
                                    }
                                }
                            },
                            onForward10 = { mediaController?.seekForward() },
                            onNext = { mediaController?.seekToNextMediaItem() },
                            onToggleShuffle = {
                                mediaController?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
                            },
                            onCycleRepeat = {
                                mediaController?.let {
                                    it.repeatMode = when (it.repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPlaylistView(
    mode: MediaMode,
    onPickFiles: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = CarColors.Surface,
        border = BorderStroke(1.5.dp, CarColors.Border)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (mode == MediaMode.VIDEO) Icons.Rounded.Movie else Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = CarColors.AccentAmber,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "A lista de reprodução está vazia.",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (mode == MediaMode.VIDEO) {
                    "Toque no botão abaixo para escolher um ou mais vídeos no telemóvel."
                } else {
                    "Toque no botão abaixo para escolher uma ou mais músicas. A música continua mesmo com o ecrã apagado."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = CarColors.TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            CarActionButton(
                text = "Escolher ficheiros",
                icon = Icons.Rounded.FolderOpen,
                onClick = onPickFiles,
                containerColor = CarColors.AccentAmber,
                contentColor = CarColors.OnAccentDark
            )
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun MediaViewport(
    mode: MediaMode,
    mediaController: MediaController?,
    currentTrackName: String,
    isPlaying: Boolean,
    errorMessage: String?,
    canSkipNext: Boolean,
    onSkipNextOnError: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = CarColors.Surface,
        border = BorderStroke(1.5.dp, CarColors.Border)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (errorMessage != null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ErrorOutline,
                        contentDescription = "Erro de reprodução",
                        tint = CarColors.AccentRed,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.titleMedium,
                        color = CarColors.TextPrimary,
                        textAlign = TextAlign.Center
                    )
                    if (canSkipNext) {
                        Spacer(modifier = Modifier.height(18.dp))
                        CarActionButton(
                            text = "Saltar para o seguinte",
                            icon = Icons.Rounded.SkipNext,
                            onClick = onSkipNextOnError,
                            containerColor = CarColors.AccentAmber,
                            contentColor = CarColors.OnAccentDark
                        )
                    }
                }
            } else if (mode == MediaMode.VIDEO) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            keepScreenOn = true
                        }
                    },
                    update = { playerView ->
                        playerView.player = mediaController
                    }
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        color = CarColors.AccentBlue.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(2.dp, CarColors.AccentBlue),
                        modifier = Modifier.size(88.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MusicNote,
                            contentDescription = "Música",
                            tint = CarColors.AccentBlue,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = currentTrackName,
                        style = MaterialTheme.typography.headlineMedium,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isPlaying) "A reproduzir · Continua com o ecrã apagado" else "Em pausa",
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (isPlaying) CarColors.AccentGreen else CarColors.TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaybackControlsSection(
    positionMs: Long,
    durationMs: Long,
    sliderProgress: Float,
    isPlaying: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    hasTracks: Boolean,
    onSeekChange: (Float) -> Unit,
    onSeekFinished: () -> Unit,
    onPrevious: () -> Unit,
    onReplay10: () -> Unit,
    onPlayPause: () -> Unit,
    onForward10: () -> Unit,
    onNext: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = CarColors.Surface,
        border = BorderStroke(1.5.dp, CarColors.Border)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Barra de progresso + tempos
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = formatDurationMs(positionMs),
                    style = MaterialTheme.typography.titleMedium,
                    color = CarColors.TextPrimary
                )

                Slider(
                    value = sliderProgress.coerceIn(0f, 1f),
                    onValueChange = onSeekChange,
                    onValueChangeFinished = onSeekFinished,
                    enabled = hasTracks && durationMs > 0L,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = CarColors.AccentAmber,
                        activeTrackColor = CarColors.AccentAmber,
                        inactiveTrackColor = CarColors.SurfaceElevated
                    )
                )

                Text(
                    text = formatDurationMs(durationMs),
                    style = MaterialTheme.typography.titleMedium,
                    color = CarColors.TextSecondary
                )
            }

            // Linha principal de controlos (>= 72 dp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CarControlIconButton(
                    icon = Icons.Rounded.Shuffle,
                    contentDescription = "Aleatório",
                    label = "Aleat.",
                    active = shuffleEnabled,
                    enabled = hasTracks,
                    onClick = onToggleShuffle,
                    modifier = Modifier.weight(1f)
                )

                CarControlIconButton(
                    icon = Icons.Rounded.SkipPrevious,
                    contentDescription = "Anterior",
                    enabled = hasTracks,
                    onClick = onPrevious,
                    modifier = Modifier.weight(1f)
                )

                CarControlIconButton(
                    icon = Icons.Rounded.Replay10,
                    contentDescription = "Recuar 10 segundos",
                    label = "-10 s",
                    enabled = hasTracks,
                    onClick = onReplay10,
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = onPlayPause,
                    enabled = hasTracks,
                    modifier = Modifier
                        .weight(1.35f)
                        .heightIn(min = 76.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CarColors.AccentAmber,
                        contentColor = CarColors.OnAccentDark
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pausar" else "Reproduzir",
                        modifier = Modifier.size(40.dp)
                    )
                }

                CarControlIconButton(
                    icon = Icons.Rounded.Forward10,
                    contentDescription = "Avançar 10 segundos",
                    label = "+10 s",
                    enabled = hasTracks,
                    onClick = onForward10,
                    modifier = Modifier.weight(1f)
                )

                CarControlIconButton(
                    icon = Icons.Rounded.SkipNext,
                    contentDescription = "Seguinte",
                    enabled = hasTracks,
                    onClick = onNext,
                    modifier = Modifier.weight(1f)
                )

                val repeatIcon = if (repeatMode == Player.REPEAT_MODE_ONE) {
                    Icons.Rounded.RepeatOne
                } else {
                    Icons.Rounded.Repeat
                }
                val repeatLabel = when (repeatMode) {
                    Player.REPEAT_MODE_ALL -> "Lista"
                    Player.REPEAT_MODE_ONE -> "1x"
                    else -> "Repetir"
                }
                CarControlIconButton(
                    icon = repeatIcon,
                    contentDescription = "Repetir",
                    label = repeatLabel,
                    active = repeatMode != Player.REPEAT_MODE_OFF,
                    enabled = hasTracks,
                    onClick = onCycleRepeat,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun PlaylistColumn(
    tracks: List<MediaTrack>,
    currentIndex: Int,
    onSelectTrack: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(currentIndex, tracks.size) {
        if (currentIndex in tracks.indices) {
            listState.animateScrollToItem(currentIndex)
        }
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = CarColors.Surface,
        border = BorderStroke(1.5.dp, CarColors.Border)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "Lista de reprodução (${tracks.size})",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)
            )

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(tracks) { index, track ->
                    val isCurrent = index == currentIndex
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 72.dp)
                            .clickable { onSelectTrack(index) },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isCurrent) CarColors.AccentAmber.copy(alpha = 0.2f) else CarColors.SurfaceElevated,
                        border = BorderStroke(
                            width = if (isCurrent) 2.dp else 1.dp,
                            color = if (isCurrent) CarColors.AccentAmber else CarColors.Border
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "${index + 1}.",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) CarColors.AccentAmber else CarColors.TextSecondary
                            )
                            Text(
                                text = track.displayName,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (isCurrent) CarColors.AccentAmber else CarColors.TextPrimary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
