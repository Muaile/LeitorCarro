package pt.leitorcarro.app.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.leitorcarro.app.ui.theme.CarColors

@Composable
fun HomeScreen(
    onOpenVideos: () -> Unit,
    onOpenYouTube: () -> Unit,
    onOpenMusic: () -> Unit
) {
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CarColors.Background)
            .padding(horizontal = 24.dp, vertical = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Cabeçalho com título e aviso de segurança permanente
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    color = CarColors.AccentAmber,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DirectionsCar,
                        contentDescription = "Leitor Carro",
                        tint = CarColors.OnAccentDark,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    )
                }
                Column {
                    Text(
                        text = "Leitor Carro",
                        style = MaterialTheme.typography.displaySmall
                    )
                    Text(
                        text = "Reprodutor multimédia para o carro",
                        style = MaterialTheme.typography.bodyLarge,
                        color = CarColors.TextSecondary
                    )
                }
            }
        }

        // Três botões enormes: Vídeos, YouTube e Música
        if (isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                HugeMainTileButton(
                    title = "Vídeos",
                    subtitle = "Ficheiros do telemóvel",
                    icon = Icons.Rounded.Movie,
                    accentColor = CarColors.AccentAmber,
                    onClick = onOpenVideos,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 180.dp)
                )
                HugeMainTileButton(
                    title = "YouTube",
                    subtitle = "Abrir m.youtube.com",
                    icon = Icons.Rounded.SmartDisplay,
                    accentColor = CarColors.AccentRed,
                    onClick = onOpenYouTube,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 180.dp)
                )
                HugeMainTileButton(
                    title = "Música",
                    subtitle = "Toca com ecrã apagado",
                    icon = Icons.Rounded.MusicNote,
                    accentColor = CarColors.AccentBlue,
                    onClick = onOpenMusic,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 180.dp)
                )
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                HugeMainTileButton(
                    title = "Vídeos",
                    subtitle = "Reproduzir vídeos locais",
                    icon = Icons.Rounded.Movie,
                    accentColor = CarColors.AccentAmber,
                    onClick = onOpenVideos,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
                HugeMainTileButton(
                    title = "YouTube",
                    subtitle = "Abrir m.youtube.com",
                    icon = Icons.Rounded.SmartDisplay,
                    accentColor = CarColors.AccentRed,
                    onClick = onOpenYouTube,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
                HugeMainTileButton(
                    title = "Música",
                    subtitle = "Áudio com ecrã apagado",
                    icon = Icons.Rounded.MusicNote,
                    accentColor = CarColors.AccentBlue,
                    onClick = onOpenMusic,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
            }
        }
    }
}

@Composable
private fun HugeMainTileButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 112.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = CarColors.Surface,
            contentColor = CarColors.TextPrimary
        ),
        border = BorderStroke(2.5.dp, accentColor),
        contentPadding = PaddingValues(24.dp)
    ) {
        val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (isLandscape) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    color = accentColor,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.size(68.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = CarColors.OnAccentDark,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = title,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = CarColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                Surface(
                    color = accentColor,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.size(68.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = CarColors.OnAccentDark,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    )
                }
                Spacer(modifier = Modifier.width(20.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = CarColors.TextPrimary,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyLarge,
                        color = CarColors.TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
