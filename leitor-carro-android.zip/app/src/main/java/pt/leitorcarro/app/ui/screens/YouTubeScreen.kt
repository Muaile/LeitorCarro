package pt.leitorcarro.app.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import pt.leitorcarro.app.ui.components.CarActionButton
import pt.leitorcarro.app.ui.theme.CarColors

private const val YOUTUBE_MOBILE_URL = "https://m.youtube.com"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeScreen(
    onNavigateHome: () -> Unit
) {
    val context = LocalContext.current
    var isOnline by remember { mutableStateOf(checkInternetConnection(context)) }
    var hasLoadError by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }
    var canGoBack by remember { mutableStateOf(false) }

    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(android.graphics.Color.BLACK)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
                displayZoomControls = false
                cacheMode = WebSettings.LOAD_DEFAULT
            }
        }
    }

    // Monitorizar ligação à internet em tempo real
    DisposableEffect(context) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                isOnline = true
            }

            override fun onLost(network: Network) {
                isOnline = checkInternetConnection(context)
            }
        }
        try {
            cm.registerDefaultNetworkCallback(callback)
        } catch (_: Exception) {
        }
        onDispose {
            try {
                cm.unregisterNetworkCallback(callback)
            } catch (_: Exception) {
            }
        }
    }

    // Configurar clientes da WebView e limpar ao sair
    DisposableEffect(webView) {
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                isLoading = true
                hasLoadError = false
                canGoBack = view?.canGoBack() == true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                isLoading = false
                canGoBack = view?.canGoBack() == true
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    isLoading = false
                    hasLoadError = true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
            }

            override fun onHideCustomView() {
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                customView = null
            }
        }

        if (checkInternetConnection(context)) {
            webView.loadUrl(YOUTUBE_MOBILE_URL)
        }

        onDispose {
            customViewCallback?.onCustomViewHidden()
            webView.stopLoading()
            webView.destroy()
        }
    }

    // Suporte à tecla voltar (sai do ecrã inteiro -> volta atrás na WebView -> volta ao ecrã inicial)
    BackHandler {
        when {
            customView != null -> {
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                customView = null
            }
            webView.canGoBack() -> {
                webView.goBack()
            }
            else -> {
                onNavigateHome()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CarColors.Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Botões grandes de navegação (>= 72 dp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CarActionButton(
                    text = "Início",
                    icon = Icons.Rounded.Home,
                    onClick = onNavigateHome,
                    modifier = Modifier.weight(1f)
                )

                CarActionButton(
                    text = "Voltar",
                    icon = Icons.Rounded.ArrowBack,
                    enabled = canGoBack,
                    onClick = {
                        if (webView.canGoBack()) {
                            webView.goBack()
                        }
                    },
                    modifier = Modifier.weight(1f)
                )

                CarActionButton(
                    text = "Recarregar",
                    icon = Icons.Rounded.Refresh,
                    onClick = {
                        isOnline = checkInternetConnection(context)
                        hasLoadError = false
                        if (isOnline) {
                            if (webView.url.isNullOrBlank()) {
                                webView.loadUrl(YOUTUBE_MOBILE_URL)
                            } else {
                                webView.reload()
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                )

                CarActionButton(
                    text = "YouTube",
                    icon = Icons.Rounded.SmartDisplay,
                    onClick = {
                        isOnline = checkInternetConnection(context)
                        hasLoadError = false
                        if (isOnline) {
                            webView.loadUrl(YOUTUBE_MOBILE_URL)
                        }
                    },
                    containerColor = CarColors.AccentRed,
                    contentColor = CarColors.TextPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            if (isLoading && isOnline && !hasLoadError) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = CarColors.AccentRed,
                    trackColor = CarColors.SurfaceElevated
                )
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(18.dp),
                color = CarColors.Surface,
                border = BorderStroke(1.5.dp, CarColors.Border)
            ) {
                if (!isOnline || hasLoadError) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WifiOff,
                            contentDescription = "Sem ligação à internet",
                            tint = CarColors.AccentAmber,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Sem ligação à internet",
                            style = MaterialTheme.typography.headlineMedium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Não foi possível abrir o YouTube. Verifique se o Wi-Fi ou os dados móveis estão ligados.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = CarColors.TextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        CarActionButton(
                            text = "Tentar novamente",
                            icon = Icons.Rounded.Refresh,
                            onClick = {
                                isOnline = checkInternetConnection(context)
                                hasLoadError = false
                                if (isOnline) {
                                    webView.loadUrl(YOUTUBE_MOBILE_URL)
                                }
                            },
                            containerColor = CarColors.AccentAmber,
                            contentColor = CarColors.OnAccentDark
                        )
                    }
                } else {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { webView }
                    )
                }
            }
        }

        // Sobreposição de vídeo em ecrã inteiro
        val activeCustomView = customView
        if (activeCustomView != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(CarColors.Background)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        FrameLayout(ctx).apply {
                            (activeCustomView.parent as? ViewGroup)?.removeView(activeCustomView)
                            addView(
                                activeCustomView,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                        }
                    }
                )

                CarActionButton(
                    text = "Sair do ecrã inteiro",
                    icon = Icons.Rounded.FullscreenExit,
                    onClick = {
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                        customView = null
                    },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                )
            }
        }
    }
}

private fun checkInternetConnection(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork ?: return false
    val capabilities = cm.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}
