package pt.leitorcarro.app.model

import androidx.media3.common.Player

enum class AppScreen {
    HOME,
    VIDEO_PLAYER,
    MUSIC_PLAYER,
    YOUTUBE
}

enum class MediaMode(val storageKey: String, val titlePt: String) {
    VIDEO("video", "Vídeos"),
    AUDIO("audio", "Música")
}

data class MediaTrack(
    val uriString: String,
    val displayName: String
)

data class SavedPlaybackState(
    val tracks: List<MediaTrack> = emptyList(),
    val currentIndex: Int = 0,
    val positionMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF
)
