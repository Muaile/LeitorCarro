package pt.leitorcarro.app

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import pt.leitorcarro.app.data.PlaylistStorage
import pt.leitorcarro.app.model.AppScreen
import pt.leitorcarro.app.model.MediaMode
import pt.leitorcarro.app.player.PlaybackService
import pt.leitorcarro.app.ui.screens.HomeScreen
import pt.leitorcarro.app.ui.screens.PlayerScreen
import pt.leitorcarro.app.ui.screens.YouTubeScreen
import pt.leitorcarro.app.ui.theme.LeitorCarroTheme

class MainActivity : ComponentActivity() {

    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Manter o ecrã sempre ligado enquanto a aplicação está aberta
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val storage = PlaylistStorage(applicationContext)

        setContent {
            LeitorCarroTheme {
                var currentScreen by rememberSaveable { mutableStateOf(AppScreen.HOME) }
                var mediaController by remember { mutableStateOf<MediaController?>(null) }
                var activeServiceMode by remember { mutableStateOf(storage.loadLastActiveMode()) }

                // Pedir permissão de notificação no Android 13+ para controlos no ecrã bloqueado
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { _ -> }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val granted = ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!granted) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                // Ligar ao MediaSessionService (ExoPlayer em segundo plano)
                DisposableEffect(Unit) {
                    val sessionToken = SessionToken(
                        applicationContext,
                        ComponentName(applicationContext, PlaybackService::class.java)
                    )
                    val future = MediaController.Builder(applicationContext, sessionToken).buildAsync()
                    controllerFuture = future
                    future.addListener(
                        {
                            try {
                                mediaController = future.get()
                            } catch (_: Exception) {
                            }
                        },
                        ContextCompat.getMainExecutor(applicationContext)
                    )

                    onDispose {
                        controllerFuture?.let { MediaController.releaseFuture(it) }
                        controllerFuture = null
                        mediaController = null
                    }
                }

                when (currentScreen) {
                    AppScreen.HOME -> {
                        HomeScreen(
                            onOpenVideos = { currentScreen = AppScreen.VIDEO_PLAYER },
                            onOpenYouTube = { currentScreen = AppScreen.YOUTUBE },
                            onOpenMusic = { currentScreen = AppScreen.MUSIC_PLAYER }
                        )
                    }

                    AppScreen.VIDEO_PLAYER -> {
                        PlayerScreen(
                            mode = MediaMode.VIDEO,
                            mediaController = mediaController,
                            activeServiceMode = activeServiceMode,
                            onActiveServiceModeChange = { activeServiceMode = it },
                            storage = storage,
                            onNavigateHome = { currentScreen = AppScreen.HOME }
                        )
                    }

                    AppScreen.MUSIC_PLAYER -> {
                        PlayerScreen(
                            mode = MediaMode.AUDIO,
                            mediaController = mediaController,
                            activeServiceMode = activeServiceMode,
                            onActiveServiceModeChange = { activeServiceMode = it },
                            storage = storage,
                            onNavigateHome = { currentScreen = AppScreen.HOME }
                        )
                    }

                    AppScreen.YOUTUBE -> {
                        YouTubeScreen(
                            onNavigateHome = { currentScreen = AppScreen.HOME }
                        )
                    }
                }
            }
        }
    }
}
