package pt.leitorcarro.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object CarColors {
    val Background = Color(0xFF07090C)
    val Surface = Color(0xFF131820)
    val SurfaceElevated = Color(0xFF1D2430)
    val Border = Color(0xFF2E384A)

    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFC2CBD9)

    val AccentAmber = Color(0xFFFF9F1C)
    val AccentBlue = Color(0xFF3B82F6)
    val AccentGreen = Color(0xFF22C55E)
    val AccentRed = Color(0xFFEF4444)
    val OnAccentDark = Color(0xFF07090C)
}

private val CarDarkColorScheme = darkColorScheme(
    primary = CarColors.AccentAmber,
    onPrimary = CarColors.OnAccentDark,
    secondary = CarColors.AccentBlue,
    onSecondary = CarColors.TextPrimary,
    tertiary = CarColors.AccentGreen,
    onTertiary = CarColors.OnAccentDark,
    background = CarColors.Background,
    onBackground = CarColors.TextPrimary,
    surface = CarColors.Surface,
    onSurface = CarColors.TextPrimary,
    surfaceVariant = CarColors.SurfaceElevated,
    onSurfaceVariant = CarColors.TextSecondary,
    error = CarColors.AccentRed,
    onError = CarColors.TextPrimary,
    outline = CarColors.Border
)

private val CarTypography = Typography(
    displaySmall = TextStyle(
        fontSize = 32.sp,
        lineHeight = 38.sp,
        fontWeight = FontWeight.Bold,
        color = CarColors.TextPrimary
    ),
    headlineMedium = TextStyle(
        fontSize = 26.sp,
        lineHeight = 32.sp,
        fontWeight = FontWeight.Bold,
        color = CarColors.TextPrimary
    ),
    titleLarge = TextStyle(
        fontSize = 22.sp,
        lineHeight = 28.sp,
        fontWeight = FontWeight.Bold,
        color = CarColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontSize = 19.sp,
        lineHeight = 25.sp,
        fontWeight = FontWeight.SemiBold,
        color = CarColors.TextPrimary
    ),
    bodyLarge = TextStyle(
        fontSize = 18.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.Medium,
        color = CarColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontSize = 16.sp,
        lineHeight = 22.sp,
        fontWeight = FontWeight.Normal,
        color = CarColors.TextSecondary
    ),
    labelLarge = TextStyle(
        fontSize = 18.sp,
        lineHeight = 22.sp,
        fontWeight = FontWeight.Bold,
        color = CarColors.TextPrimary
    )
)

@Composable
fun LeitorCarroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CarDarkColorScheme,
        typography = CarTypography,
        content = content
    )
}
